package com.example.apka6

import android.util.Log

class Tasker (var title:String) {

    fun xd (){
        println(title)
    }
}