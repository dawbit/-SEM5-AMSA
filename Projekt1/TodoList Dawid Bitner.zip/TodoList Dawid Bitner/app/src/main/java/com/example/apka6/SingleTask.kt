package com.example.apka6

class SingleTask(var taskName : String,
                 var taskPriority : String,
                 var taskState : String,
                 var taskDate : String,
                 var taskid:Long?=null) {
}