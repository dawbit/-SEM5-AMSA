package com.imdb.imdb_api.ui.films

class FilmsClass(var filmTitle : String, var filmYear : String, var filmPoster: String , var filmID:Long?=null) {

}