package com.imdb.imdb_api.ui.films.filmDetail

class DetailFilmDirectorClass(var Director: String) {
}