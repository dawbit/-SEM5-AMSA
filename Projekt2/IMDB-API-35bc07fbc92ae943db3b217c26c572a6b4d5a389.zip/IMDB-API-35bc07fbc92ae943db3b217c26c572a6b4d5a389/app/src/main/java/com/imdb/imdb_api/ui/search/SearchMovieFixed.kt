package com.imdb.imdb_api.ui.search

class SearchMovieFixed (val Search : List<SearchFilmApi> , var Response:String) {
}