package com.imdb.imdb_api.ui.actors

class ActorsClass(var actorName : String, var actorID:Long?=null) {
}