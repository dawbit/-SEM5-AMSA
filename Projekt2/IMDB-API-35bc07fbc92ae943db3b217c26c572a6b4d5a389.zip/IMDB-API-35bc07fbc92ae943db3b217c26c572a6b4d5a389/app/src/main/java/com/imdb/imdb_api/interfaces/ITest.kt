package com.imdb.imdb_api.interfaces

interface ITest {

    fun funkcja(){

    }
}