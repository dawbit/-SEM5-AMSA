package com.imdb.imdb_api.ui.search

class SearchFilmApi(var Title: String, var Poster: String, var Year: String) {
}