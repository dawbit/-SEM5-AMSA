package com.imdb.imdb_api.ui.films.filmDetail

class DetailFilmActorsClass(var Actors: String) {
}