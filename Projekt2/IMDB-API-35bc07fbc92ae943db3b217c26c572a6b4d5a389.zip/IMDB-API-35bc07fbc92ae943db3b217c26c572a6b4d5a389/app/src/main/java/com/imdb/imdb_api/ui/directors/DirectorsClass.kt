package com.imdb.imdb_api.ui.directors

class DirectorsClass(var directorName : String, var directorID:Long?=null) {
}