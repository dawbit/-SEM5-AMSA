interface Idrawable {
    fun draw()
}