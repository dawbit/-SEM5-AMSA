abstract class Figure{
    abstract var pole : Double
    abstract var obwod : Double
    private var _kolor : String = "none"

    var kolor : String
        get() = _kolor
        set(value) {
            _kolor = value
        }

}