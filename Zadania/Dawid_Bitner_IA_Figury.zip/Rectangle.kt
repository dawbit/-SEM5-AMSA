class Rectangle(
    bok1 : Double,
    bok2 : Double,
    kolor : String = "none"
):Figure(),Idrawable
{
    override var pole = bok1 * bok2
    override var obwod = 2*bok1 + 2*bok2

    init{
        super.kolor = kolor
    }

    override fun draw(){
        println("Rysuje prostokat o polu $pole i obwodzie $obwod i kolorze $kolor")
    }
}