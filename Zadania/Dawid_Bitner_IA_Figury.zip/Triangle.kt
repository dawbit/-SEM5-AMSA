import kotlin.math.sqrt

class Triangle(
    podstawa : Double,
    wysokosc : Double,
    kolor : String = "none"
):Figure(),Idrawable
{
    override var pole = (podstawa * wysokosc)/2
    override var obwod = podstawa + wysokosc+ sqrt(podstawa*podstawa+wysokosc*wysokosc)

    init{
        super.kolor = kolor
    }

    override fun draw(){
        println("Rysuje trójkąt o polu $pole i obwodzie $obwod i kolorze $kolor")
    }
}