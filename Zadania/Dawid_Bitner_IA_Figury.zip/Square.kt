class Square(
    bok1 : Double,
    kolor : String = "none"
):Figure(),Idrawable
{
    override var pole = bok1*bok1
    override var obwod = 4*bok1

    init{
        super.kolor = kolor
    }

    override fun draw(){
        println("Rysuje kwadrat o polu $pole, obwodzie $obwod i kolorze $kolor")
    }
}