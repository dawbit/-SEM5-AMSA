fun main(){
    var figury = mutableListOf<Figure>()
    figury.add(Rectangle(10.0,10.0,"różowy"))
    figury.add(Rectangle(20.0,30.0))
    figury.add(Square(10.0,"fioletowy"))
    figury.add(Square(40.0))
    figury.add(Triangle(10.0,5.0))
    figury.add(Triangle(10.0,5.0,"pomarańczowy"))
    figury.add(Circle(10.0))
    figury.add(Circle(10.0,"czarny"))


    for (element:Figure in figury){
        (element as? Idrawable)?.draw()
    }

}