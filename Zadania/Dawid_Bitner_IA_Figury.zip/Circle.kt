import kotlin.math.PI

class Circle(
    promien : Double,
    kolor : String = "none"
):Figure(),Idrawable
{
    override var pole = PI*promien*promien
    override var obwod = 2*PI*promien

    init{
        super.kolor = kolor
    }

    override fun draw(){
        println("Rysuje koło o polu $pole i obwodzie $obwod i kolorze $kolor")
    }
}