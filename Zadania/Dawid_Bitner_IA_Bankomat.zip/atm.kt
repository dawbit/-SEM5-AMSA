import kotlin.math.floor

class atm(
    private var sum10: Int = 5,
    private var sum20: Int = 10,
    private var sum50: Int = 2,
    private var sum100: Int = 10,
    private var sum200: Int = 0,
    private var sum500: Int = 1
)
{
    var balance: Int = sum10 * 10 + sum20 * 20 + sum50 * 50 + sum100 * 100 + sum200 * 200 + sum500 * 500

    fun checkMoney(money : Double) : Boolean {


        return when {
            money % 10.0 != 0.0 -> {
                println("Nie można wypłacić takiej sumy!")
                false
            }
            money > balance -> {
                println("Brak wystarczających środków w bankomacie!")
                false
            }
            else -> true
        }
    }

        fun withdrawMoney(money : Double) {
            var money1 = money
            if(checkMoney(money)){
            println("Srodki dostepne przed operacja: $balance zł")
            if (money1 / 500.0 > 0.0) {
                var f_hun = floor(money / 500.0)
                if (f_hun <= sum500) {
                    money1 -= f_hun * 500
                    sum500 -= f_hun.toInt()
                    println("Wypłacam $f_hun banknotów 500 zł")
                } else {
                    money1 -= sum500 * 500
                    sum500 = 0
                    println("Wypłacam $sum500 banknotów 500 zł")
                }
            }

            if (money1 / 200.0 > 0.0) {
                var t_hun = floor(money / 200.0)
                if (t_hun <= sum200) {
                    money1 -= t_hun * 200
                    sum200 -= t_hun.toInt()
                    println("Wypłacam $t_hun banknotów 200 zł")
                } else {
                    money1 -= sum200 * 200
                    sum200 = 0
                    println("Wypłacam $sum200 banknotów 200 zł")
                }
            }

            if (money1 / 100.0 > 0.0) {
                var hun = floor(money / 100.0)
                if (hun <= sum100) {
                    money1 -= hun * 100
                    sum100 -= hun.toInt()
                    println("Wypłacam $hun banknotów 100 zł")
                } else {
                    money1 -= sum100 * 100
                    sum100 = 0
                    println("Wypłacam $sum100 banknotów 100 zł")
                }
            }

            if (money1 / 50.0 > 0.0) {
                var fif = floor(money / 50.0)
                if (fif <= sum50) {
                    money1 -= fif * 50
                    sum50 -= fif.toInt()
                    println("Wypłacam $fif banknotów 50 zł")
                } else {
                    money1 -= sum50 * 50
                    sum50 = 0
                    println("Wypłacam $sum50 banknotów 50 zł")
                }
            }

            if (money1 / 20.0 > 0.0) {
                var twe = floor(money / 20.0)
                if (twe <= sum20) {
                    money1 -= twe * 20
                    sum20 -= twe.toInt()
                    println("Wypłacam $twe banknotów 20 zł")
                } else {
                    money1 -= sum20 * 20
                    sum20 = 0
                    println("Wypłacam $sum20 banknotów 20 zł")
                }
            }

            if (money1 / 10.0 > 0.0) {
                var te = floor(money / 10.0)
                if (te <= sum10) {
                    money1 -= te * 10
                    sum10 -= te.toInt()
                    println("Wypłacam $te banknotów 10 zł")
                } else {
                    money1 -= sum10 * 10
                    sum10 = 0
                    println("Wypłacam $sum10 banknotów 10 zł")
                }
            }

            balance -= money.toInt()
            println("Wypłacono $money zł")
            println("Srodki dostepne po operacji: $balance zł")

        }

    }
}