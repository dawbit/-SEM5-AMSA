fun main(){
    val bankomat = atm()
    val firstuser = user("Jan","Kowalski", 10000.0)

    println(firstuser)
    println("========================")

    if(firstuser.checkBalance(2000) && bankomat.checkMoney(2000.0)) {
        bankomat.withdrawMoney(2000.0)
        firstuser.withdrawMoney(2000)
    }
    println(firstuser)
    println("========================")

    if(firstuser.checkBalance(200) && bankomat.checkMoney(200.0)) {
        //println(firstuser.checkBalance(2000)) true
        bankomat.withdrawMoney(200.0)
        firstuser.withdrawMoney(200)
    }
    println(firstuser)
    println("========================")

}
