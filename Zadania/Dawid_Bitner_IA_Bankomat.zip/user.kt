open class user(
    private val firstname: String,
    private val surname: String,
    private var balance: Double = 0.0
) {
    override fun toString(): String = "$firstname $surname $balance"

    fun checkBalance(money: Int): Boolean {
        return if(money > balance) {
            println("Brak wystarczających środków na koncie!")
            false
        } else true
    }

    fun withdrawMoney(money: Int) {
        if (money <= balance && money % 10 == 0) {
            balance -= money
            println("Wypłacono $money zł")
        }
    }
}

